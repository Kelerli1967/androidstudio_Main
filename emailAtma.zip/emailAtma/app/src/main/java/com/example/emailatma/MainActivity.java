package com.example.emailatma;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button = findViewById(R.id.btnAt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] email = {"61kelerli@gmail.com"};
                sendMail(email,"deneme","deneme");
            }
        });
    }
    private void sendMail(String[] eMail, String konu, String mesaj) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL,eMail);
        intent.putExtra(Intent.EXTRA_SUBJECT,konu);
        intent.putExtra(Intent.EXTRA_TEXT,mesaj);
        intent.setType("message/rfc822");
        startActivity(intent);
    }
}