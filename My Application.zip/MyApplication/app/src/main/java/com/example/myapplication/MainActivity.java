package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etMesaj , etNumara;
    Button smsYolla;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        etMesaj = findViewById(R.id.etMesaj);
        etNumara = findViewById(R.id.etNumara);
        smsYolla = findViewById(R.id.smsYolla);
        smsYolla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mesaj = etMesaj.getText().toString();
                String no = etNumara.getText().toString();
//              Intent sms = new Intent(Intent.ACTION_SENDTO, Uri.parse("sms" + no));
//              sms.putExtra("sms_body","Merhaba Dünya");
//              startActivity(sms);
                SmsManager sms = SmsManager.getDefault();
                ArrayList<String> lst = sms.divideMessage(mesaj);
                sms.sendMultipartTextMessage(no, null, lst, null, null);
            }
        });
    }
}