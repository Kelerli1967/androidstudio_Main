package com.example.myapplication_4;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.gsm.SmsMessage;
import android.view.View;

import com.example.myapplication_4.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity{
static MainActivity MainActivity;
static ActivityMainBinding Binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Binding = ActivityMainBinding.inflate(getLayoutInflater());
        View view = Binding.getRoot();
        setContentView(view);
        MainActivity = this;
        ActivityCompat.requestPermissions(this,new String[] {
                Manifest.permission.READ_SMS , Manifest.permission.RECEIVE_SMS
        } , PackageManager.PERMISSION_GRANTED);
    }
    public static MainActivity getInstance()
    {
        return MainActivity;
    }
    public static class SmsAlici extends BroadcastReceiver{

        @Override
        public void onReceive(Context context, Intent intent) {
        if (
                intent.getAction().equals("android.provider.Telephony.SMS_RECEIVED")){
            Bundle bundle = intent.getExtras();
            SmsMessage [] mesajlar;
            String gonderen_numara;
            String mesaj;
            if(bundle!=null){
                Object [] pdus=(Object[])bundle.get("pdus");
                mesajlar = new SmsMessage[pdus.length];
                for (int i = 0 ; i < pdus.length ; i++){
                    mesajlar[i] = SmsMessage.createFromPdu((byte[]) pdus [i]);
                    gonderen_numara = mesajlar[i].getDisplayOriginatingAddress();
                    mesaj = mesajlar [i].getMessageBody();
                    MainActivity.getInstance();
                    Binding.etMesaj.setText(mesaj);
                    MainActivity.getInstance();
                    Binding.etNo.setText(gonderen_numara);
                    }
                }
            }
        }
    }
}